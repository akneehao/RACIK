# Racik — AI Meal Planner (frontend prototype)

A client-side prototype of Racik, an AI meal-planning tool for MBG (Makan
Bergizi Gratis) kitchen coordinators. Generates a weekly meal tray, then
gives coordinators three working views on top of it — Procurement, Stock &
Audit, and Settings — matching the four-tab structure of the original
TanStack Router app this was adapted from.

No build step, no dependencies. Open `index.html` through a local server
(ES modules require `http://`, not `file://`, in most browsers) and it
runs entirely in the browser using static, illustrative data in place of
a real AI backend and pricing API.

```
npx serve .
# or: python3 -m http.server 8000
```

## Structure

```
index.html            all markup: onboarding screens + the 4-tab app shell
css/
  styles.css           every style, using CSS custom properties for the palette
js/
  main.js              entry point — imports and wires up every other module
  state.js              shared mutable app state (single source of truth)
  utils.js               formatting, toast, screen/tab visibility helpers
  data.js                 static recipe pool + inline SVG dish illustrations
  aggregation.js           ingredient aggregation shared by Procurement & Inventory
  onboarding.js           Screens 1–2: location, then duration/budget/people
  plan.js                Screens 3–4: weekly tray + day detail ("Meal Plan" tab)
  procurement.js         "Procurement" tab: weekly/daily shopping lists, CSV export
  inventory.js           "Stock & Audit" tab: budget chart, compliance, stock table
  shell.js              sidebar tab-switching shell shown once a plan exists
  settings.js            "Settings" tab: parameters, feedback log, exports
```

## How data flows

1. **Onboarding** (`onboarding.js`) collects location, duration, budget, and
   people into `state`, then calls `buildTray()`.
2. **`buildTray()`** (`plan.js`) walks the selected days and assigns each one
   a recipe from the static pool in `data.js`, storing the result in
   `state.generatedDays`. This is the one place a real deployment would swap
   in an actual AI/optimizer call.
3. Every other tab reads from `state.generatedDays` on demand:
   - **Procurement** and **Inventory** both call `aggregateIngredients()`
     (`aggregation.js`) to turn per-dish ingredient lists into a shopping list.
   - **Inventory** additionally keeps its own editable records in
     `state.inventoryRecords`, keyed `` `${dayKey}::${ingredientName}` `` so
     each ingredient has independent received/used/actual-cost values.
4. **Settings → Regenerate Plan** updates `state.people`, calls `buildTray()`
   again, resets `state.inventoryRecords`, and asks Procurement/Inventory to
   re-render — this is the pattern to follow if you add more editable
   parameters later.

## Known simplifications

- `recipePool` is a fixed array of 7 dishes, cycled through by index — a real
  build would replace `buildTray()`'s recipe-selection line with a call to
  the actual generation/optimizer backend.
- Costs, nutrition figures, and inventory variances are illustrative, not
  sourced from real pricing or nutrition datasets.
- Export buttons (PDF / image / CSV-from-Settings) are stubbed with a toast;
  only the Procurement and Inventory CSV downloads are fully functional,
  since those just serialize data already in `state`.
